from django.shortcuts import render, render_to_response
from django.template import RequestContext
from goodadmin.models import User, Competition, StockPick
from django.http import HttpResponse
from django.contrib.auth import authenticate, login

def index(request):

  context = RequestContext(request)
  context_dict = {'username':request.user.username}
  
  print(request.user.username)
  print(type(request.user.username))
  
  if not request.user.is_authenticated():
    return render_to_response("goodadmin/login_register.html", context_dict, context)
   
  
  
  
  
  
  
  
  return render_to_response("goodadmin/index.html", context_dict, context)

  
def dashboardsales(request):

  context = RequestContext(request)
  
  
  context_dict = {}
  if not request.user.is_authenticated():
    return render_to_response("goodadmin/login.html", context_dict, context)
  
  
  
  return render_to_response("goodadmin/dashboard-sales.html", context_dict, context)


def my_scores(request):

  context = RequestContext(request)
  
  
  context_dict = {}
  
  if not request.user.is_authenticated():
    return render_to_response("goodadmin/login_register.html", context_dict, context)
  
  
  
  return render_to_response("goodadmin/components-text-person.html", context_dict, context)  

def face(request):

  context = RequestContext(request)
  
  
  context_dict = {}
  
  if not request.user.is_authenticated():
    return render_to_response("goodadmin/login.html", context_dict, context)
  
  
  
  return render_to_response("goodadmin/landing_index.html", context_dict, context) 


  
  
def race_status(request):

  context = RequestContext(request)
  
  
  stockpicks = list(StockPick.objects.order_by('StockPickPrice')[:10])
  
  context_dict = {'picks': stockpicks}
  
  if not request.user.is_authenticated():
    return render_to_response("goodadmin/login_register.html", context_dict, context)
  
  
  
  
  
  
  
  return render_to_response("goodadmin/components-text.html", context_dict, context)
  


def login_action(request):

   context = RequestContext(request)
   context_dict = {}

   if request.method == 'POST':
      
        username = request.POST.get('form-username')
        password = request.POST.get('form-password')
		
        user = authenticate(username=username, password=password)
		
        if user:		
           if user.is_active:
		   
             login(request, user)
             context_dict['userid'] = request.user.id
			 
             return render_to_response("goodadmin/index.html", context_dict, context)
           else:
             return render_to_response("goodadmin/login_register.html", context_dict, context)
		
		
        else:
          return render_to_response("goodadmin/login_register.html", context_dict, context) 
		
   else:
       return render_to_response("goodadmin/login_register.html", context_dict, context)	
		
		
		
		
		
		
  
  
  