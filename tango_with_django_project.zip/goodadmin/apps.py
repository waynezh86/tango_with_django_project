from django.apps import AppConfig


class GoodadminConfig(AppConfig):
    name = 'goodadmin'
