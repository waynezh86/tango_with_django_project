from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class UserProfile(models.Model):
    IDname = models.CharField(max_length=128, unique = True)
    Email = models.CharField(max_length=128, unique = True)
    RegisterIP = models.CharField(max_length=128, unique = True)
    RegisterDate = models.DateField()
	
    user = models.OneToOneField(User)
	
    def __str__(self):
     return self.IDname
	   
	   
class Competition(models.Model):
    CompID = models.CharField(max_length=128, default = 1, unique = True)
    StartDate = models.DateField()  #competition starting date
    Interval = models.IntegerField(default = 0)  #competition lasting time
    EndDate = models.DateField()  #competition ending date
	 
    def __str__(self): 
     return self.CompID
	 

class StockPick(models.Model):
    IDname = models.ForeignKey(User)
    CompID = models.ForeignKey(Competition)
    StockTicker = models.CharField(max_length=50) #stock ticker picked
    PickDate = models.DateField() # stock picking date
    StockPickPrice = models.FloatField(default = 0.0) # stock price when picked
	
    def __str__(self): 
     return self.StockTicker